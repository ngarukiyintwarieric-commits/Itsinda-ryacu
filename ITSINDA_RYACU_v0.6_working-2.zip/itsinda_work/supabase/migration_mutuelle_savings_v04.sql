-- ITSINDA RYACU v0.4: Mutuelle de Santé savings planning
-- Apply this migration in Supabase SQL Editor after reviewing it.
-- This records savings plans and user-entered savings entries. It does NOT process
-- official Mutuelle payments and does NOT independently verify cash/mobile-money receipts.

create table if not exists public.mutuelle_savings_plans (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references auth.users(id) on delete cascade,
  household_label text not null check (char_length(trim(household_label)) between 1 and 120),
  target_amount bigint not null check (target_amount > 0),
  due_date date not null,
  frequency text not null check (frequency in ('weekly','monthly')),
  planned_contribution bigint not null check (planned_contribution > 0),
  created_at timestamptz not null default now()
);

create table if not exists public.mutuelle_savings_contributions (
  id uuid primary key default gen_random_uuid(),
  plan_id uuid not null references public.mutuelle_savings_plans(id) on delete cascade,
  owner_id uuid not null references auth.users(id) on delete cascade,
  amount bigint not null check (amount > 0),
  contributed_on date not null default current_date,
  note text not null default '' check (char_length(note) <= 500),
  verification_status text not null default 'recorded'
    check (verification_status in ('recorded','confirmed')),
  created_at timestamptz not null default now(),
  constraint mutuelle_contribution_owner_matches_plan
    check (owner_id is not null)
);

create index if not exists mutuelle_plans_owner_created_idx
  on public.mutuelle_savings_plans(owner_id, created_at desc);
create index if not exists mutuelle_contributions_owner_date_idx
  on public.mutuelle_savings_contributions(owner_id, contributed_on desc);
create index if not exists mutuelle_contributions_plan_idx
  on public.mutuelle_savings_contributions(plan_id);

alter table public.mutuelle_savings_plans enable row level security;
alter table public.mutuelle_savings_contributions enable row level security;

drop policy if exists "mutuelle_plans_select_own" on public.mutuelle_savings_plans;
create policy "mutuelle_plans_select_own" on public.mutuelle_savings_plans
for select to authenticated using (owner_id = (select auth.uid()));

drop policy if exists "mutuelle_plans_insert_own" on public.mutuelle_savings_plans;
create policy "mutuelle_plans_insert_own" on public.mutuelle_savings_plans
for insert to authenticated with check (owner_id = (select auth.uid()));

drop policy if exists "mutuelle_plans_update_own" on public.mutuelle_savings_plans;
create policy "mutuelle_plans_update_own" on public.mutuelle_savings_plans
for update to authenticated using (owner_id = (select auth.uid()))
with check (owner_id = (select auth.uid()));

drop policy if exists "mutuelle_contributions_select_own" on public.mutuelle_savings_contributions;
create policy "mutuelle_contributions_select_own" on public.mutuelle_savings_contributions
for select to authenticated using (
  owner_id = (select auth.uid()) and exists (
    select 1 from public.mutuelle_savings_plans p
    where p.id = plan_id and p.owner_id = (select auth.uid())
  )
);

drop policy if exists "mutuelle_contributions_insert_own_plan" on public.mutuelle_savings_contributions;
create policy "mutuelle_contributions_insert_own_plan" on public.mutuelle_savings_contributions
for insert to authenticated with check (
  owner_id = (select auth.uid()) and exists (
    select 1 from public.mutuelle_savings_plans p
    where p.id = plan_id and p.owner_id = (select auth.uid())
  )
);

-- Deliberately no client-side update/delete policy for contribution records.
-- Production should add a trusted treasurer confirmation workflow and immutable audit trail.
