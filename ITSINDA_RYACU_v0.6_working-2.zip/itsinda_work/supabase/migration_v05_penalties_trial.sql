-- ITSINDA RYACU v0.5: penalty rules, penalty records, and 3-month group trial metadata.
-- Review this migration before applying it to the live Supabase project.
-- It does not collect/store national ID numbers and does not process payments.

create table if not exists public.group_penalty_approvers (
  id uuid primary key default gen_random_uuid(),
  group_id uuid not null references public.savings_groups(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  approver_role text not null check (approver_role in ('leader','committee')),
  added_by uuid not null references auth.users(id),
  created_at timestamptz not null default now(),
  unique (group_id, user_id)
);

create table if not exists public.group_penalty_rules (
  id uuid primary key default gen_random_uuid(),
  group_id uuid not null references public.savings_groups(id) on delete cascade,
  title text not null check (char_length(trim(title)) between 2 and 120),
  reason text not null default '' check (char_length(reason) <= 500),
  calculation_method text not null check (calculation_method in ('fixed','daily','weekly','custom')),
  amount bigint not null check (amount > 0),
  grace_days integer not null default 0 check (grace_days between 0 and 365),
  max_amount bigint check (max_amount is null or max_amount >= amount),
  is_active boolean not null default true,
  approved_by uuid references auth.users(id),
  approved_at timestamptz,
  created_by uuid not null references auth.users(id),
  created_at timestamptz not null default now()
);

create table if not exists public.group_penalties (
  id uuid primary key default gen_random_uuid(),
  group_id uuid not null references public.savings_groups(id) on delete cascade,
  rule_id uuid references public.group_penalty_rules(id) on delete set null,
  member_label text not null check (char_length(trim(member_label)) between 1 and 120),
  reason text not null check (char_length(trim(reason)) between 2 and 500),
  amount bigint not null check (amount > 0),
  due_date date,
  days_late integer not null default 0 check (days_late >= 0),
  status text not null default 'pending' check (status in ('pending','approved','paid','cancelled')),
  created_by uuid not null references auth.users(id),
  approved_by uuid references auth.users(id),
  approved_at timestamptz,
  paid_by uuid references auth.users(id),
  paid_at timestamptz,
  payment_note text not null default '' check (char_length(payment_note) <= 500),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index if not exists group_penalty_rules_group_idx on public.group_penalty_rules(group_id, created_at desc);
create index if not exists group_penalties_group_status_idx on public.group_penalties(group_id, status, created_at desc);
create index if not exists group_penalty_approvers_user_idx on public.group_penalty_approvers(user_id, group_id);

alter table public.group_penalty_approvers enable row level security;
alter table public.group_penalty_rules enable row level security;
alter table public.group_penalties enable row level security;

-- Approver list: creator can manage; the listed approver can see their own assignment.
drop policy if exists "penalty_approvers_read" on public.group_penalty_approvers;
create policy "penalty_approvers_read" on public.group_penalty_approvers for select to authenticated
using (user_id = (select auth.uid()) or exists (
  select 1 from public.savings_groups g where g.id = group_id and g.created_by = (select auth.uid())
));
drop policy if exists "penalty_approvers_add_by_group_creator" on public.group_penalty_approvers;
create policy "penalty_approvers_add_by_group_creator" on public.group_penalty_approvers for insert to authenticated
with check (added_by = (select auth.uid()) and exists (
  select 1 from public.savings_groups g where g.id = group_id and g.created_by = (select auth.uid())
));
drop policy if exists "penalty_approvers_delete_by_group_creator" on public.group_penalty_approvers;
create policy "penalty_approvers_delete_by_group_creator" on public.group_penalty_approvers for delete to authenticated
using (exists (select 1 from public.savings_groups g where g.id = group_id and g.created_by = (select auth.uid())));

-- Read rules/penalties only when creator or assigned leader/committee member.
drop policy if exists "penalty_rules_select_authorized" on public.group_penalty_rules;
create policy "penalty_rules_select_authorized" on public.group_penalty_rules for select to authenticated using (
  exists (select 1 from public.savings_groups g where g.id = group_id and g.created_by = (select auth.uid()))
  or exists (select 1 from public.group_penalty_approvers a where a.group_id = group_penalty_rules.group_id and a.user_id = (select auth.uid()))
);
drop policy if exists "penalty_rules_insert_authorized" on public.group_penalty_rules;
create policy "penalty_rules_insert_authorized" on public.group_penalty_rules for insert to authenticated with check (
  created_by = (select auth.uid()) and (
    exists (select 1 from public.savings_groups g where g.id = group_id and g.created_by = (select auth.uid()))
    or exists (select 1 from public.group_penalty_approvers a where a.group_id = group_penalty_rules.group_id and a.user_id = (select auth.uid()))
  )
);
drop policy if exists "penalty_rules_update_authorized" on public.group_penalty_rules;
create policy "penalty_rules_update_authorized" on public.group_penalty_rules for update to authenticated using (
  exists (select 1 from public.savings_groups g where g.id = group_id and g.created_by = (select auth.uid()))
  or exists (select 1 from public.group_penalty_approvers a where a.group_id = group_penalty_rules.group_id and a.user_id = (select auth.uid()))
) with check (
  exists (select 1 from public.savings_groups g where g.id = group_id and g.created_by = (select auth.uid()))
  or exists (select 1 from public.group_penalty_approvers a where a.group_id = group_penalty_rules.group_id and a.user_id = (select auth.uid()))
);

drop policy if exists "penalties_select_authorized" on public.group_penalties;
create policy "penalties_select_authorized" on public.group_penalties for select to authenticated using (
  exists (select 1 from public.savings_groups g where g.id = group_id and g.created_by = (select auth.uid()))
  or exists (select 1 from public.group_penalty_approvers a where a.group_id = group_penalties.group_id and a.user_id = (select auth.uid()))
);
drop policy if exists "penalties_insert_authorized" on public.group_penalties;
create policy "penalties_insert_authorized" on public.group_penalties for insert to authenticated with check (
  created_by = (select auth.uid()) and (
    exists (select 1 from public.savings_groups g where g.id = group_id and g.created_by = (select auth.uid()))
    or exists (select 1 from public.group_penalty_approvers a where a.group_id = group_penalties.group_id and a.user_id = (select auth.uid()))
  )
);
drop policy if exists "penalties_update_authorized" on public.group_penalties;
create policy "penalties_update_authorized" on public.group_penalties for update to authenticated using (
  exists (select 1 from public.savings_groups g where g.id = group_id and g.created_by = (select auth.uid()))
  or exists (select 1 from public.group_penalty_approvers a where a.group_id = group_penalties.group_id and a.user_id = (select auth.uid()))
) with check (
  exists (select 1 from public.savings_groups g where g.id = group_id and g.created_by = (select auth.uid()))
  or exists (select 1 from public.group_penalty_approvers a where a.group_id = group_penalties.group_id and a.user_id = (select auth.uid()))
);

-- A group gets a 3-month trial. This is trial metadata only; no payment provider is connected yet.
create table if not exists public.group_subscriptions (
  id uuid primary key default gen_random_uuid(),
  group_id uuid not null unique references public.savings_groups(id) on delete cascade,
  plan text not null default 'free' check (plan in ('free','pro_small','pro_standard','enterprise')),
  trial_started_at timestamptz not null default now(),
  trial_ends_at timestamptz not null default (now() + interval '3 months'),
  status text not null default 'trial' check (status in ('trial','active','expired','cancelled')),
  monthly_price_rwf integer not null default 0 check (monthly_price_rwf >= 0),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
alter table public.group_subscriptions enable row level security;
drop policy if exists "subscriptions_select_group_creator" on public.group_subscriptions;
create policy "subscriptions_select_group_creator" on public.group_subscriptions for select to authenticated using (
  exists (select 1 from public.savings_groups g where g.id = group_id and g.created_by = (select auth.uid()))
);
drop policy if exists "subscriptions_insert_group_creator" on public.group_subscriptions;
create policy "subscriptions_insert_group_creator" on public.group_subscriptions for insert to authenticated with check (
  exists (select 1 from public.savings_groups g where g.id = group_id and g.created_by = (select auth.uid()))
);
drop policy if exists "subscriptions_update_group_creator" on public.group_subscriptions;
create policy "subscriptions_update_group_creator" on public.group_subscriptions for update to authenticated using (
  exists (select 1 from public.savings_groups g where g.id = group_id and g.created_by = (select auth.uid()))
) with check (
  exists (select 1 from public.savings_groups g where g.id = group_id and g.created_by = (select auth.uid()))
);

-- NOTE: no national ID is stored here. Identity verification needs an approved verification provider.
-- NOTE: SMS OTP requires enabling/configuring a supported SMS provider in Supabase Auth.
-- NOTE: a payment provider and server-side webhook verification are required before charging for Pro.

-- Append-only audit trail for penalty-rule and penalty changes.
create table if not exists public.group_penalty_audit_log (
  id uuid primary key default gen_random_uuid(),
  group_id uuid not null references public.savings_groups(id) on delete cascade,
  record_type text not null check (record_type in ('rule','penalty')),
  record_id uuid not null,
  action text not null check (action in ('created','updated')),
  actor_id uuid references auth.users(id),
  old_data jsonb,
  new_data jsonb,
  created_at timestamptz not null default now()
);
create index if not exists group_penalty_audit_group_created_idx on public.group_penalty_audit_log(group_id, created_at desc);
alter table public.group_penalty_audit_log enable row level security;
drop policy if exists "penalty_audit_select_authorized" on public.group_penalty_audit_log;
create policy "penalty_audit_select_authorized" on public.group_penalty_audit_log for select to authenticated using (
  exists (select 1 from public.savings_groups g where g.id = group_id and g.created_by = (select auth.uid()))
  or exists (select 1 from public.group_penalty_approvers a where a.group_id = group_penalty_audit_log.group_id and a.user_id = (select auth.uid()))
);

create or replace function public.log_group_penalty_change()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
declare
  v_group_id uuid;
  v_record_id uuid;
  v_old jsonb;
  v_new jsonb;
  v_kind text;
  v_action text;
begin
  v_kind := case when tg_table_name = 'group_penalty_rules' then 'rule' else 'penalty' end;
  if tg_op = 'INSERT' then
    v_group_id := new.group_id;
    v_record_id := new.id;
    v_new := to_jsonb(new);
    v_action := 'created';
  else
    v_group_id := new.group_id;
    v_record_id := new.id;
    v_old := to_jsonb(old);
    v_new := to_jsonb(new);
    v_action := 'updated';
  end if;
  insert into public.group_penalty_audit_log(group_id, record_type, record_id, action, actor_id, old_data, new_data)
  values (v_group_id, v_kind, v_record_id, v_action, auth.uid(), v_old, v_new);
  return new;
end;
$$;

drop trigger if exists group_penalty_rules_audit on public.group_penalty_rules;
create trigger group_penalty_rules_audit after insert or update on public.group_penalty_rules
for each row execute function public.log_group_penalty_change();
drop trigger if exists group_penalties_audit on public.group_penalties;
create trigger group_penalties_audit after insert or update on public.group_penalties
for each row execute function public.log_group_penalty_change();

-- Ensure approval/payment actor fields can only name the currently authenticated actor.
drop policy if exists "penalty_rules_update_authorized" on public.group_penalty_rules;
create policy "penalty_rules_update_authorized" on public.group_penalty_rules for update to authenticated using (
  exists (select 1 from public.savings_groups g where g.id = group_id and g.created_by = (select auth.uid()))
  or exists (select 1 from public.group_penalty_approvers a where a.group_id = group_penalty_rules.group_id and a.user_id = (select auth.uid()))
) with check (
  (approved_by is null or approved_by = (select auth.uid())) and (
    exists (select 1 from public.savings_groups g where g.id = group_id and g.created_by = (select auth.uid()))
    or exists (select 1 from public.group_penalty_approvers a where a.group_id = group_penalty_rules.group_id and a.user_id = (select auth.uid()))
  )
);
drop policy if exists "penalties_update_authorized" on public.group_penalties;
create policy "penalties_update_authorized" on public.group_penalties for update to authenticated using (
  exists (select 1 from public.savings_groups g where g.id = group_id and g.created_by = (select auth.uid()))
  or exists (select 1 from public.group_penalty_approvers a where a.group_id = group_penalties.group_id and a.user_id = (select auth.uid()))
) with check (
  (approved_by is null or approved_by = (select auth.uid())) and (paid_by is null or paid_by = (select auth.uid())) and (
    exists (select 1 from public.savings_groups g where g.id = group_id and g.created_by = (select auth.uid()))
    or exists (select 1 from public.group_penalty_approvers a where a.group_id = group_penalties.group_id and a.user_id = (select auth.uid()))
  )
);
