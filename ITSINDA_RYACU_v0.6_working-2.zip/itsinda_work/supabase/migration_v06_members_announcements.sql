-- ITSINDA RYACU v0.6: members, individual contributions, announcements and group end date.
-- Review and back up your project before applying. Does not delete existing records.
alter table public.savings_groups add column if not exists planned_end_date date, add column if not exists reminder_days_before integer not null default 7 check (reminder_days_before between 0 and 90);
create table if not exists public.group_members (
 id uuid primary key default gen_random_uuid(), group_id uuid not null references public.savings_groups(id) on delete cascade,
 user_id uuid references auth.users(id) on delete set null, full_name text not null check (char_length(trim(full_name)) between 2 and 120),
 phone text not null, monthly_due bigint not null default 0 check (monthly_due >= 0), joined_at date not null default current_date,
 is_active boolean not null default true, created_by uuid not null references auth.users(id), created_at timestamptz not null default now(), unique(group_id,phone), unique(id,group_id));
create index if not exists group_members_group_idx on public.group_members(group_id);
create index if not exists group_members_user_idx on public.group_members(user_id);
create table if not exists public.group_member_contributions (
 id uuid primary key default gen_random_uuid(), group_id uuid not null references public.savings_groups(id) on delete cascade,
 member_id uuid not null, amount bigint not null check(amount > 0),
 paid_on date not null default current_date, contribution_month date, note text not null default '',
 status text not null default 'recorded' check(status in ('recorded','confirmed','rejected')),
 recorded_by uuid not null references auth.users(id), confirmed_by uuid references auth.users(id), confirmed_at timestamptz, created_at timestamptz not null default now(), foreign key(member_id,group_id) references public.group_members(id,group_id) on delete cascade);
create index if not exists group_member_contrib_group_idx on public.group_member_contributions(group_id,paid_on desc);
create index if not exists group_member_contrib_member_idx on public.group_member_contributions(member_id,paid_on desc);
create table if not exists public.group_announcements (
 id uuid primary key default gen_random_uuid(), group_id uuid not null references public.savings_groups(id) on delete cascade,
 title text not null check(char_length(trim(title)) between 2 and 140), message text not null check(char_length(trim(message)) between 2 and 1200),
 created_by uuid not null references auth.users(id), created_at timestamptz not null default now(),
 send_status text not null default 'draft' check(send_status in ('draft','sending','sent','partial','failed')),
 total_recipients integer not null default 0, sent_count integer not null default 0, failed_count integer not null default 0, provider_reference text);
create index if not exists group_announcements_group_idx on public.group_announcements(group_id,created_at desc);
create table if not exists public.group_announcement_recipients (
 id uuid primary key default gen_random_uuid(), announcement_id uuid not null references public.group_announcements(id) on delete cascade,
 member_id uuid references public.group_members(id) on delete set null, phone text not null,
 delivery_status text not null default 'queued' check(delivery_status in ('queued','sent','delivered','failed')),
 provider_message_id text, error_message text, created_at timestamptz not null default now(), unique(announcement_id,phone));
create index if not exists announcement_recipients_announcement_idx on public.group_announcement_recipients(announcement_id);
alter table public.group_members enable row level security;
alter table public.group_member_contributions enable row level security;
alter table public.group_announcements enable row level security;
alter table public.group_announcement_recipients enable row level security;
drop policy if exists "group owners manage members" on public.group_members;
create policy "group owners manage members" on public.group_members for all to authenticated using(exists(select 1 from public.savings_groups g where g.id=group_members.group_id and g.created_by=auth.uid())) with check(exists(select 1 from public.savings_groups g where g.id=group_members.group_id and g.created_by=auth.uid()) and group_members.created_by=auth.uid());
drop policy if exists "members read own membership" on public.group_members;
create policy "members read own membership" on public.group_members for select to authenticated using(user_id=auth.uid());
drop policy if exists "group owners manage member contributions" on public.group_member_contributions;
create policy "group owners manage member contributions" on public.group_member_contributions for all to authenticated using(exists(select 1 from public.savings_groups g where g.id=group_member_contributions.group_id and g.created_by=auth.uid())) with check(exists(select 1 from public.savings_groups g where g.id=group_member_contributions.group_id and g.created_by=auth.uid()) and group_member_contributions.recorded_by=auth.uid());
drop policy if exists "members read own contributions" on public.group_member_contributions;
create policy "members read own contributions" on public.group_member_contributions for select to authenticated using(exists(select 1 from public.group_members m where m.id=member_id and m.user_id=auth.uid()));
drop policy if exists "group owners manage announcements" on public.group_announcements;
create policy "group owners manage announcements" on public.group_announcements for all to authenticated using(exists(select 1 from public.savings_groups g where g.id=group_announcements.group_id and g.created_by=auth.uid())) with check(exists(select 1 from public.savings_groups g where g.id=group_announcements.group_id and g.created_by=auth.uid()) and group_announcements.created_by=auth.uid());
drop policy if exists "members read group announcements" on public.group_announcements;
create policy "members read group announcements" on public.group_announcements for select to authenticated using(exists(select 1 from public.group_members m where m.group_id=group_announcements.group_id and m.user_id=auth.uid()));
drop policy if exists "group owners read announcement recipients" on public.group_announcement_recipients;
create policy "group owners read announcement recipients" on public.group_announcement_recipients for select to authenticated using(exists(select 1 from public.group_announcements a join public.savings_groups g on g.id=a.group_id where a.id=announcement_id and g.created_by=auth.uid()));
comment on table public.group_member_contributions is 'Manually recorded contributions; confirmed means confirmed by authorized group officer, not bank verified.';
comment on table public.group_announcements is 'SMS delivery requires configured send-group-announcement Edge Function and SMS provider.';
