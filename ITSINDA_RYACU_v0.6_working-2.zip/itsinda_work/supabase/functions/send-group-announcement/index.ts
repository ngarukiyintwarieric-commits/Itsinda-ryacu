import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });
  if (req.method !== "POST") return new Response(JSON.stringify({ error: "Method not allowed" }), { status: 405, headers: { ...corsHeaders, "Content-Type": "application/json" } });

  try {
    const url = Deno.env.get("SUPABASE_URL");
    const anonKey = Deno.env.get("SUPABASE_ANON_KEY");
    const serviceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
    const sid = Deno.env.get("TWILIO_ACCOUNT_SID");
    const token = Deno.env.get("TWILIO_AUTH_TOKEN");
    const from = Deno.env.get("TWILIO_FROM_NUMBER");
    if (!url || !anonKey || !serviceKey) throw new Error("Supabase function secrets are missing.");
    if (!sid || !token || !from) throw new Error("SMS provider is not configured. Set TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN and TWILIO_FROM_NUMBER.");

    const authHeader = req.headers.get("Authorization") ?? "";
    const userClient = createClient(url, anonKey, { global: { headers: { Authorization: authHeader } }, auth: { persistSession: false } });
    const { data: userData, error: userError } = await userClient.auth.getUser();
    if (userError || !userData.user) return new Response(JSON.stringify({ error: "Unauthorized" }), { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } });

    const { announcement_id } = await req.json();
    if (typeof announcement_id !== "string") throw new Error("announcement_id is required.");
    const admin = createClient(url, serviceKey, { auth: { persistSession: false } });
    const { data: announcement, error: announcementError } = await admin.from("group_announcements").select("id,group_id,title,message,created_by").eq("id", announcement_id).single();
    if (announcementError || !announcement) throw new Error("Announcement not found.");
    const { data: group } = await admin.from("savings_groups").select("id,created_by,name").eq("id", announcement.group_id).single();
    if (!group || group.created_by !== userData.user.id || announcement.created_by !== userData.user.id) {
      return new Response(JSON.stringify({ error: "Only the group owner who created this announcement may send it." }), { status: 403, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }
    const { data: members, error: membersError } = await admin.from("group_members").select("id,phone").eq("group_id", announcement.group_id).eq("is_active", true);
    if (membersError) throw membersError;
    const recipients = (members ?? []).filter((m) => /^\+?[1-9]\d{7,14}$/.test(String(m.phone).replace(/[\s()-]/g, "")));
    if (!recipients.length) throw new Error("No active members with valid phone numbers were found.");
    await admin.from("group_announcements").update({ send_status: "sending", total_recipients: recipients.length, sent_count: 0, failed_count: 0 }).eq("id", announcement_id);

    let sent = 0; let failed = 0;
    for (const member of recipients) {
      const phone = String(member.phone).replace(/[\s()-]/g, "");
      const form = new URLSearchParams({ To: phone, From: from, Body: `${announcement.title}: ${announcement.message}` });
      const response = await fetch(`https://api.twilio.com/2010-04-01/Accounts/${sid}/Messages.json`, {
        method: "POST",
        headers: { Authorization: `Basic ${btoa(`${sid}:${token}`)}`, "Content-Type": "application/x-www-form-urlencoded" },
        body: form,
      });
      const result = await response.json().catch(() => ({}));
      await admin.from("group_announcement_recipients").upsert({ announcement_id, member_id: member.id, phone, delivery_status: response.ok ? "sent" : "failed", provider_message_id: result.sid ?? null, error_message: response.ok ? null : String(result.message ?? "SMS provider rejected message").slice(0, 500) }, { onConflict: "announcement_id,phone" });
      if (response.ok) sent++; else failed++;
    }
    const status = sent === recipients.length ? "sent" : sent > 0 ? "partial" : "failed";
    await admin.from("group_announcements").update({ send_status: status, total_recipients: recipients.length, sent_count: sent, failed_count: failed }).eq("id", announcement_id);
    return new Response(JSON.stringify({ announcement_id, total: recipients.length, sent, failed, status, note: "sent means accepted by the SMS provider; delivery receipt availability depends on provider configuration." }), { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } });
  } catch (error) {
    return new Response(JSON.stringify({ error: error instanceof Error ? error.message : "Unexpected error" }), { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } });
  }
});
