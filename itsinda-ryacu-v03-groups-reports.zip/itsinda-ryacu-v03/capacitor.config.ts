import type { CapacitorConfig } from "@capacitor/cli";

const config: CapacitorConfig = {
  appId: "rw.itsindaryacu.app",
  appName: "ITSINDA RYACU",
  webDir: "dist"
};

export default config;